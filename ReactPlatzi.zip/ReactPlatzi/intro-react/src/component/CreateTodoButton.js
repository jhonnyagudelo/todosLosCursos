import React from "react";
import "../css/TodoButton.css";

function CreateTodoButton() {
  const onClickButton = (msg) => {
    alert(msg);
  };
  return (
    <button
      className="CreateTodoButton"
      type="submit"
      onClick={() => onClickButton("Aquio deberia de abrir un modal")}
    >
      +
    </button>
  );
}

export { CreateTodoButton };
